#ifndef __LUNAIX_RAMFS_H
#define __LUNAIX_RAMFS_H

void
ramfs_init();

#endif /* __LUNAIX_RAMFS_H */
