#ifndef __LUNAIX_DEVFS_H
#define __LUNAIX_DEVFS_H

void
devfs_init();

#endif /* __LUNAIX_DEVFS_H */
