#ifndef __LUNAIX_SDBG_PROTOCOL_H
#define __LUNAIX_SDBG_PROTOCOL_H

/**
 * @brief Initialize Serial Debugger
 *
 */
void
sdbg_init();

#endif /* __LUNAIX_SDBG_H */
